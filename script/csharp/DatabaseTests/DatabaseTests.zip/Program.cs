﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using BinarySerialization;
using DIVALib.Databases;

namespace DatabaseTests
{
    class MainClass
    {
        [FieldOrder(0)] public int Count;
        [FieldOrder(1)] public int Offset;
        [FieldOrder(2), FieldCount("Count"), FieldOffset("Offset")] public List<Entries> Entries;
    }

    class Entries
    {
        [FieldOrder(0)] public int id;
        [FieldOrder(1)] public int Offset;
        [FieldOrder(2), FieldEncoding("ASCII"), FieldOffset(0)] public string String;
    }


    class Program
    {
        static void Main(string[] args)
        {
            var file = new FileStream(@"D:\Emulators\RPSC3\dev_hdd0\game\NPJB00134\USRDIR\rom\objset\tex_db.bin", FileMode.Open);
            file = new FileStream(@"D:\QuickBMS\nez_txp\tst.file", FileMode.Open);
            var serial = new BinarySerializer() {Endianness = Endianness.Little};

            var tst = serial.Deserialize<MainClass>(file);
            
            Console.WriteLine(tst);
            Console.ReadLine(); 

        }
    }
}
